package org.example.validator;

public class PesoValidador implements IValidacoes {
    @Override
    public void validar(double peso) {
        if (peso <= 0) {
            throw new RuntimeException("Peso não pode ser igual a 0 ou negativo");
        }
    }
}
