package org.example.validator;

public interface IValidacoes {
    public void validar(double valor);
}
