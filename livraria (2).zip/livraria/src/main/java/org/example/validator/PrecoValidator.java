package org.example.validator;

public class PrecoValidator implements IValidacoes{
    @Override
    public void validar(double preco) {
        if (preco <= 0) {
            throw new RuntimeException("Preço não pode ser igual ou menor que 0");
        }
    }
}
