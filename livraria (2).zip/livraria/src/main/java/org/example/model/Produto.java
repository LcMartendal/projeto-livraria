package org.example.model;

import org.example.validator.PesoValidador;
import org.example.validator.PrecoValidator;

public class Produto {

    private String nome;
    private double peso;
    private double preco;
    private PesoValidador pesoValidador;
    private PrecoValidator precoValidator;

    public Produto(String nome, double peso, double preco) {
        pesoValidador.validar(peso);
        precoValidator.validar(preco);
        
        this.nome = nome;
        this.peso = peso;
        this.preco = preco;
    }

    public double getPeso() {
        return peso;
    }

    public double getPreco() {
        return preco;
    }

    public String getNome() {
        return nome;
    }
}