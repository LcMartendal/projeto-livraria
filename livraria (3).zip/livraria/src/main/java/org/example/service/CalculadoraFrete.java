package org.example.service;

import org.example.frete.ITipoFrete;
import org.example.model.Pedido;

public class CalculadoraFrete {

    public double calcular(Pedido pedido, ITipoFrete tipoFrete) {
        return tipoFrete.calcularFrete(pedido);
    }
}