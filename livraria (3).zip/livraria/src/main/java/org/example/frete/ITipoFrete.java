package org.example.frete;

import org.example.model.Pedido;

public interface ITipoFrete {
    double calcularFrete(Pedido pedido);
}