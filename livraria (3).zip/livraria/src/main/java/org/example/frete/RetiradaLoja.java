package org.example.frete;

import org.example.model.Pedido;

public class RetiradaLoja implements ITipoFrete {
    @Override
    public double calcularFrete(Pedido pedido) {
        return 0;
    }
}